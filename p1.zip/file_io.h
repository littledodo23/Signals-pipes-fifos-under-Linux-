#ifndef FILE_IO_H
#define FILE_IO_H

#include "matrix.h"


void load_matrices_from_file(const char *filename);

#endif
