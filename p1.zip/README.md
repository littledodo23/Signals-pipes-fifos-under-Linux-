# Signals-pipes-fifos-under-Linux-

TO RUN CODE:

gcc -Wall -Wextra -g -fopenmp main.c eigen.c worker_pool.c matrix.c file_io.c config.c -o matrix_ops -lm

./matrix_ops
